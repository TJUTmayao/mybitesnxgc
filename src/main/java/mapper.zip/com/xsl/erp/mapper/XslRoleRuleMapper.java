package com.xsl.erp.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import xsl.erp.pojo.XslRoleRule;
import xsl.erp.pojo.XslRoleRuleExample;

public interface XslRoleRuleMapper {
    long countByExample(XslRoleRuleExample example);

    int deleteByExample(XslRoleRuleExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(XslRoleRule record);

    int insertSelective(XslRoleRule record);

    List<XslRoleRule> selectByExample(XslRoleRuleExample example);

    XslRoleRule selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") XslRoleRule record, @Param("example") XslRoleRuleExample example);

    int updateByExample(@Param("record") XslRoleRule record, @Param("example") XslRoleRuleExample example);

    int updateByPrimaryKeySelective(XslRoleRule record);

    int updateByPrimaryKey(XslRoleRule record);
}