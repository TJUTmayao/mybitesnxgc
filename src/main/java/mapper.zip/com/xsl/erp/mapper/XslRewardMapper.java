package com.xsl.erp.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import xsl.erp.pojo.XslReward;
import xsl.erp.pojo.XslRewardExample;

public interface XslRewardMapper {
    long countByExample(XslRewardExample example);

    int deleteByExample(XslRewardExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(XslReward record);

    int insertSelective(XslReward record);

    List<XslReward> selectByExample(XslRewardExample example);

    XslReward selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") XslReward record, @Param("example") XslRewardExample example);

    int updateByExample(@Param("record") XslReward record, @Param("example") XslRewardExample example);

    int updateByPrimaryKeySelective(XslReward record);

    int updateByPrimaryKey(XslReward record);
}